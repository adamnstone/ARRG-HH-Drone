# ESP32-S3 drone direction-of-arrival (DOA)

This ESP-IDF 5.x example implements GCC-PHAT and deterministic 3D unit direction estimation with a T-shaped microphone array. **It is a simulator + DSP engine, not plug-and-play three-INMP441 capture firmware.** There is no Python dependency on the microcontroller. The firmware prints test directions and estimates on serial.

## Build and flash

Install ESP-IDF 5.x and use the IDF terminal:

```bash
idf.py set-target esp32s3
idf.py build
idf.py -p COM5 flash monitor
```

Change `COM5` to your device port. Simulation mode runs without microphones.

## Geometry and conventions

- Sample rate 16,000 Hz; buffer 2,048 samples (128 ms) per channel.
- Mics left `(-0.1,0,0)` m, right `(0.1,0,0)` m, stem `(0,-0.1,0)` m.
- +Z above the microphone plane is assumed (below indistinguishable).
- `doa_estimate(channels, &result)` returns a unit direction `(x,y,z)`, azimuth, elevation, delays, and horizon-clamp flag. Not source range.
- Peak lag estimation uses FFT GCC-PHAT followed by quadratic sub-sample interpolation; unlike the Python simulation's oversampled GCC, this uses a non-interpolated 2048-point FFT with parabolic refinement, so predictions will not match exactly.
- FFT correlation is *circular* within its 2048-sample buffer; Hann weighting and a physically limited lag search mitigate edge artifacts but do not replace a full linear-convolution zero-padded FFT implementation.

## Critical real hardware work still required

The ESP32-S3 offers two stereo I2S controllers, but three INMP441s do **not** inherently yield three aligned samples from the same clock. Two mics can share a left/right standard-I2S bus; the third needs a specifically engineered clock-synchronous capture arrangement or different microphone interface. Independent I2S start calls **do not guarantee** per-sample alignment. Do not claim physical angular accuracy until all channels have synchronized frames, calibrated per-channel timing, and actual measurement validation.

To integrate physical capture, replace `acquire_three_channels()` in `main.cpp` with a hardware acquisition function that fills `channels[3][DOA_N]` from aligned samples. Check channel order, 24-bit INMP441 conversion, clocking, buffering, wind-noise mitigation and sensor alignment. Planar array assumes a source above the plane. For real-time tracking, run repeated captures and smooth vectors/quality-gate suspicious estimates.

Performance and memory are **not yet benchmarked on a physical ESP32-S3**. Do not interpret test-mode estimates as validated GCC-PHAT accuracy. A design using externally synchronized multichannel audio hardware is a safer first prototype.
