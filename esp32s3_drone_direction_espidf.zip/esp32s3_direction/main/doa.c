#include "doa.h"
#include <math.h>
#include <string.h>
#include <stddef.h>
#define PI 3.14159265358979323846f
// FFT based, PHAT-normalized cross-correlation, implementing forward/inverse radix-2 FFT.
// Only 2048 samples (128 ms) processed per call; no NumPy/ML dependency.
typedef struct {float re, im;} complex_t;
static complex_t freq[3][DOA_N];
static complex_t crosscorr[DOA_N];
static float lag_score[DOA_N];

static void fft(complex_t *a, int inverse) {
  for (unsigned i=1,j=0;i<DOA_N;++i) {
    unsigned bit=DOA_N>>1;
    for (; j & bit; bit >>=1) j^=bit;
    j^=bit;
    if (i<j) {complex_t tmp=a[i];a[i]=a[j];a[j]=tmp;}
  }
  for (int len=2;len<=DOA_N;len<<=1) {
    float angle=(inverse?2.f:-2.f)*PI/(float)len;
    float wr=cosf(angle),wi=sinf(angle);
    for (int base=0;base<DOA_N;base+=len) {
      float cr=1.f,ci=0.f;
      for (int k=0;k<len/2;k++) {
        complex_t u=a[base+k],v=a[base+k+len/2];
        float vr=v.re*cr-v.im*ci,vi=v.re*ci+v.im*cr;
        a[base+k]=(complex_t){u.re+vr,u.im+vi};
        a[base+k+len/2]=(complex_t){u.re-vr,u.im-vi};
        float nr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=nr;
      }
    }
  }
  if (inverse) for(int i=0;i<DOA_N;i++){a[i].re/=DOA_N;a[i].im/=DOA_N;}
}
static int lag_samples(int mic, float max_lag, float *peak_out, float *lag_out) {
  // Corr(mic, left) should peak at positive lag if mic arrives later.
  for(int k=0;k<DOA_N;k++) {
    complex_t a=freq[mic][k],b=freq[0][k];
    float re=a.re*b.re+a.im*b.im;
    float im=a.im*b.re-a.re*b.im;
    float mag=sqrtf(re*re+im*im);
    if(mag>1e-9f){re/=mag;im/=mag;}else {re=0;im=0;}
    crosscorr[k]=(complex_t){re,im};
  }
  fft(crosscorr,1);
  for(int k=0;k<DOA_N;k++)lag_score[k]=fabsf(crosscorr[k].re);
  int max_shift=(int)ceilf(max_lag)+1;
  if(max_shift>=DOA_N/2)return -1;
  float best=-1;int best_lag=0;
  for(int lag=-max_shift;lag<=max_shift;lag++) {
    int idx=(lag+DOA_N)%DOA_N;
    if(lag_score[idx]>best){best=lag_score[idx];best_lag=lag;}
  }
  int idx=(best_lag+DOA_N)%DOA_N;
  float left=lag_score[(idx-1+DOA_N)%DOA_N],center=lag_score[idx],right=lag_score[(idx+1)%DOA_N];
  float denom=left-2.f*center+right;
  float fraction=0.f;
  if(fabsf(denom)>1e-10f)fraction=fmaxf(-0.5f,fminf(0.5f,0.5f*(left-right)/denom));
  *lag_out=(float)best_lag+fraction;*peak_out=best;
  return best>0.001f?0:-1;
}
int doa_estimate(const float audio[3][DOA_N], doa_result_t *out) {
  if(!audio||!out)return -1;
  for(int ch=0;ch<3;ch++) {
    float mean=0,rms=0;
    for(int i=0;i<DOA_N;i++)mean+=audio[ch][i];
    mean/=DOA_N;
    for(int i=0;i<DOA_N;i++){
      float v=audio[ch][i]-mean;
      rms+=v*v;
      float window=0.5f-0.5f*cosf(2.f*PI*i/(DOA_N-1));
      freq[ch][i]=(complex_t){v*window,0};
    }
    if(rms/DOA_N<1e-9f)return -1;
    fft(freq[ch],0);
  }
  float lr,ls,pr,ps;
  if(lag_samples(1,(2.f*DOA_SPACING_M/DOA_C)*DOA_FS,&pr,&lr))return -1;
  if(lag_samples(2,(sqrtf(2.f)*DOA_SPACING_M/DOA_C)*DOA_FS,&ps,&ls))return -1;
  // Mics left=(-d,0), right=(d,0), stem=(0,-d).
  // tau_i0 = -dot(r_i-r_0,u)/c.
  float x= -DOA_C*(lr/DOA_FS)/(2.f*DOA_SPACING_M);
  float y= x+ DOA_C*(ls/DOA_FS)/DOA_SPACING_M;
  float r2=x*x+y*y;
  bool invalid=r2>1.f;
  if(invalid){float norm=sqrtf(r2);x/=norm;y/=norm;r2=1.f;}
  float z=sqrtf(fmaxf(0.f,1.f-r2));
  *out=(doa_result_t){.x=x,.y=y,.z=z,
     .azimuth_deg=atan2f(y,x)*180.f/PI,
     .elevation_deg=atan2f(z,sqrtf(x*x+y*y))*180.f/PI,
     .lag_right_samples=lr,.lag_stem_samples=ls,
     .projected_to_horizon=invalid,.peak_right=pr,.peak_stem=ps};
  return 0;
}
