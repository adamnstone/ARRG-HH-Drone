#pragma once
#include <stdbool.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define DOA_N 2048
#define DOA_FS 16000
#define DOA_SPACING_M 0.10f
#define DOA_C 343.0f
// Three channels must be sample-synchronized; audio[ch][sample].
typedef struct {float x,y,z,azimuth_deg,elevation_deg; float lag_right_samples,lag_stem_samples; bool projected_to_horizon; float peak_right,peak_stem;} doa_result_t;
// Returns 0 on success; -1 for invalid/ambiguous audio. FFT computation is deterministic.
int doa_estimate(const float audio[3][DOA_N], doa_result_t *out);
#ifdef __cplusplus
}
#endif
