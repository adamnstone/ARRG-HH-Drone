#include <cmath>
#include <cstdint>
#include <cstdio>
#include "esp_log.h"
#include "doa.h"
// DEMO MODE: generates common broadband signal with simulated fractional-sample delays.
// REPLACE acquire_three_channels() with *genuinely synchronized* 3-channel capture.
// Three bare INMP441s are NOT plug-and-play three-channel I2S on ESP32-S3.
static const char *TAG="DOA";
static float channels[3][DOA_N];
static float source[DOA_N+32];
static uint32_t state=0xAC103FEu;
static float noise_sample(){
    state^=state<<13;state^=state>>17;state^=state<<5;
    return ((state&0xffff)/32768.f)-1.f;
}
static float interpolate(int idx,float shift){
    float at=idx-shift+12;
    int k=(int)floorf(at);float f=at-k;
    if(k<0||k+1>=DOA_N+32)return 0;
    return source[k]*(1.f-f)+source[k+1]*f;
}
static bool acquire_three_channels(float azimuth_deg,float elevation_deg){
    // Synthetic test only. The output is not a measured hardware DOA.
    float az=azimuth_deg*3.14159265f/180.f,el=elevation_deg*3.14159265f/180.f;
    float x=cosf(el)*cosf(az),y=cosf(el)*sinf(az);
    float d=DOA_SPACING_M;
    float positions[3][2]={{-d,0},{d,0},{0,-d}};
    float tau[3];float mint=1e9f;
    for(int i=0;i<3;i++){
       tau[i]=-(positions[i][0]*x+positions[i][1]*y)/DOA_C;
       if(tau[i]<mint)mint=tau[i];
    }
    for(float &v: source) v=noise_sample();
    for(int ch=0;ch<3;ch++){
       float shift=(tau[ch]-mint)*DOA_FS;
       for(int i=0;i<DOA_N;i++) channels[ch][i]=interpolate(i,shift)+noise_sample()*0.01f;
    }
    return true;
}
extern "C" void app_main(void){
    ESP_LOGW(TAG,"SIMULATION ONLY: Three-channel physical microphone capture is not implemented.");
    for(int step=0;step<12;step++){
       float az=-120.f+step*20.f,el=35.f;
       if(!acquire_three_channels(az,el))continue;
       doa_result_t r={};
       if(doa_estimate(channels,&r)==0){
           ESP_LOGI(TAG,"true az=%.1f el=%.1f | estimated az=%.1f el=%.1f | u=[%.3f %.3f %.3f] | lags=[%.2f %.2f] | horizon=%d",az,el,r.azimuth_deg,r.elevation_deg,r.x,r.y,r.z,r.lag_right_samples,r.lag_stem_samples,(int)r.projected_to_horizon);
       } else ESP_LOGW(TAG,"No valid lag estimate");
    }
}
