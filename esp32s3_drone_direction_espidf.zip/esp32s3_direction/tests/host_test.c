#include "doa.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
static float x[3][DOA_N];
static float s[DOA_N+32];
static uint32_t seed=12345678;
static float rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return ((seed&65535)/32768.f)-1.f;}
int main(void){
  for(int i=0;i<DOA_N+32;i++)s[i]=rnd();
  float az=40.f*3.14159265f/180.f, el=30.f*3.14159265f/180.f;
  float ux=cosf(el)*cosf(az),uy=cosf(el)*sinf(az);
  float p[3][2]={{-0.1f,0},{0.1f,0},{0,-0.1f}};
  float delays[3],min=100;
  for(int c=0;c<3;c++){delays[c]=-(p[c][0]*ux+p[c][1]*uy)*DOA_FS/DOA_C;if(delays[c]<min)min=delays[c];}
  for(int c=0;c<3;c++)for(int i=0;i<DOA_N;i++){
    float at=i-(delays[c]-min)+12;int j=(int)floorf(at);float f=at-j;
    x[c][i]=s[j]*(1-f)+s[j+1]*f;
  }
  doa_result_t r={0};int code=doa_estimate(x,&r);
  printf("code=%d az=%.2f el=%.2f expected=40,30 lags=%.3f %.3f\n",code,r.azimuth_deg,r.elevation_deg,r.lag_right_samples,r.lag_stem_samples);
  return code != 0 || fabsf(r.azimuth_deg-40.f)>12.f || fabsf(r.elevation_deg-30.f)>20.f;
}
